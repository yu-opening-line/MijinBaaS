#!/bin/bash
java -XX:+PrintHeapAtGC -XX:+PrintClassHistogram -XX:+PrintGCDetails -XX:+HeapDumpOnOutOfMemoryError -Xms2G -Xmx6G -XX:+PrintGC -XX:+PrintGCDateStamps -Xloggc:"./gc.txt" -cp ".:./serverjars/*" org.nem.deploy.CommonStarter
