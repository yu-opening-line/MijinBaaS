#!/bin/bash
java -Xms6G -Xmx6G -XX:+PrintGC -XX:+PrintGCDateStamps -Xloggc:"./gc.txt" -cp ".:./serverjars/*" org.nem.deploy.CommonStarter
