#!/bin/bash
cwd=`dirname "${0}"`
expr "${0}" : "/.*" > /dev/null || cwd=`(cd "${cwd}" && pwd)`
cd $cwd
java -Xms6G -Xmx6G -XX:+PrintGC -XX:+PrintGCDateStamps -Xloggc:"./gc.txt" -cp ".:./serverjars/*" org.nem.deploy.CommonStarter
